﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gaia.Infrastructure.Newtonsoft.Converters
{
    public class SigmaAttributeConverter: JsonConverter
    {
    }
}
