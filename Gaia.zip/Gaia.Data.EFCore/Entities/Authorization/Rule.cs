﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using Axis.Sigma.Policy;

namespace Gaia.Data.EFCore.Entities.Authorization
{
    //public class Rule: BaseEntity<Guid>
    //{
    //    public Effect EvaluationEffect { get; set; }
    //    public string Code { get; set; }

    //    [ForeignKey(nameof(PolicyId))]
    //    public Policy Policy { get; set; }
    //    public Guid PolicyId { get; set; }
    //}
}
