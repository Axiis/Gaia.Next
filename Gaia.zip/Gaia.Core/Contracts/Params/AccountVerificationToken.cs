﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gaia.Core.Contracts.Params
{
    public class AccountVerificationToken
    {
    }
}
